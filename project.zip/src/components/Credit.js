import "../App.css";
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
function App() {
  return (

      <div className="credits">
        <div className="credit-text">
          BucksRenovations© 2022 All rights reserved.
        </div>
      </div>
  );
}

export default App;
